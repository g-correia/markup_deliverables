# Shiny App on Malaria Cases

This Shiny application provides an interactive visualization of Malaria cases in the Northern region of Brazil for 2017.

The app can also be accessed via: https://biblioteca.shinyapps.io/shiny_malaria/